<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Opss.. 404 Not Found</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,700,800&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/font-awesome/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/perfectscroll/perfect-scrollbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/apexcharts/apexcharts.css')); ?>" rel="stylesheet">

    <!-- Theme Styles -->
    <link href="<?php echo e(asset('/assets/css/main.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/css/custom.css')); ?>" rel="stylesheet">

</head>

<body>

    <body class="error-page err-404">
        <div class='loader'>
            <div class='spinner-grow text-primary' role='status'>
                <span class='sr-only'>Loading...</span>
            </div>
        </div>

        <div class="container">
            <div class="error-container">
                <div class="error-info">
                    <h1>404</h1>
                    <p>It seems that the page you are looking for no longer exists.<br>Please contact our <a
                            href="#">help center</a> or go to the <a href="index.html">homepage</a>.</p>
                </div>
                <div class="error-image"></div>
            </div>
        </div>

        <!-- Javascripts -->
        <script src="<?php echo e(asset('/assets/plugins/jquery/jquery-3.4.1.min.js')); ?>"></script>
        <script src="https://unpkg.com/@popperjs/core@2"></script>
        <script src="<?php echo e(asset('/assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <script src="https://unpkg.com/feather-icons"></script>
        <script src="<?php echo e(asset('/assets/plugins/perfectscroll/perfect-scrollbar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/assets/js/main.min.js')); ?>"></script>
        <script src="<?php echo e(asset('/assets/js/pages/dashboard.js')); ?>"></script>

    </body>

</body>

</html>
<?php /**PATH C:\Users\Ihsan\Desktop\toko-laptop-app\vendor\laravel\framework\src\Illuminate\Foundation\Exceptions/views/404.blade.php ENDPATH**/ ?>