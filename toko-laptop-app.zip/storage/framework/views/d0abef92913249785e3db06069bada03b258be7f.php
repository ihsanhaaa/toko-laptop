

<?php $__env->startSection('content'); ?>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            <strong>Success!</strong> <?php echo e($message); ?>.
        </div>
    <?php endif; ?>

    <a href="<?php echo e(route('product.create')); ?>" class="btn btn-primary">Tambah Produk Baru</a>

    <div class="card-body">
        <h5 class="card-title">List Produk</h5>
        <table id="zero-conf" class="display" style="width:100%">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Konfirmasi</th>
                    <th>Dibuat</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(++$key); ?></td>
                        <td><?php echo e($product->judul); ?></td>
                        <td>Rp. <?php echo e(number_format((float) $product->harga)); ?></td>
                        <td>
                            <?php if($product->status == 0): ?>
                                <span class="badge bg-success mb-3">Masih Tersedia</span>
                            <?php else: ?>
                                <span class="badge bg-danger mb-3">Sudah Terjual</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if(!$product->status): ?>
                                <form action="<?php echo e(route('product.status', $product->id)); ?>" method="post"
                                    onclick="return confirm('Apakah anda yakin ingin mengkonfirmasi ini?')">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-success"><i
                                            class="fas fa-check-circle"></i>&nbsp;Konfirmasi</button>
                                </form>
                            <?php endif; ?>
                        </td>
                        <td><?php echo e($product->created_at); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>No</th>
                    <th>Nama Produk</th>
                    <th>Harga</th>
                    <th>Status</th>
                    <th>Konfirmasi</th>
                    <th>Dibuat</th>
                </tr>
            </tfoot>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ihsan\Desktop\toko-laptop-app\resources\views/product/index.blade.php ENDPATH**/ ?>