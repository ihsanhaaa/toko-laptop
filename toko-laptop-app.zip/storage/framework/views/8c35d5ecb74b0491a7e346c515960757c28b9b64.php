<div class="vlt-site-holder animsition vlt-footer-fixed">
    <div class="vlt-content-holder">
        <header class="vlt-header-holder vlt-header-fixed" data-header-fixed="1">
            <div class="container">
                <div class="vlt-header-inner">
                    <div class="vlt-header-left">
                        <a href="<?php echo e(url('/')); ?>" class="vlt-site-logo">
                            <img src="assets/img/logo.png" alt="Vinero" style="max-height: 13px">
                        </a>
                    </div>
                    <div class="vlt-header-right">
                        <div class="vlt-menu-toggle vlt-fullscreen-menu-toggle" data-before-text="Menu">
                            <span class="line line-one"><span class="inner"></span></span>
                            <span class="line line-two"><span class="inner"></span></span>
                            <span class="line line-three"><span class="inner"></span></span>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!-- /.vlt-header-holder vlt-header-fixed -->
        <div class="vlt-navigation-fullscreen-holder">
            <div class="vlt-navigation-fullscreen">
                <ul>
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="<?php echo e(route('product.index')); ?>">Product</a></li>
                    <li><a href="<?php echo e(route('product.create')); ?>">Tambah Product</a></li>
                    <li>
                        <a class="dropdown-item text-danger" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                               document.getElementById('logout-form').submit();"><i
                                class="bx bx-power-off font-size-17 align-middle me-1 text-danger"></i>Keluar
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\Ihsan\Desktop\toko-laptop-app\resources\views/components/navbar_admin.blade.php ENDPATH**/ ?>