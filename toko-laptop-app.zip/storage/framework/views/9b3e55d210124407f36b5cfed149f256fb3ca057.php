<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Ihsan Haryansyah</title>

    <!-- Styles -->
    <link href="https://fonts.googleapis.com/css?family=Poppins:400,500,700,800&display=swap" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/font-awesome/css/all.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/perfectscroll/perfect-scrollbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/plugins/apexcharts/apexcharts.css')); ?>" rel="stylesheet">


    <!-- Theme Styles -->
    <link href="<?php echo e(asset('/assets/css/main.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/assets/css/custom.css')); ?>" rel="stylesheet">

    <link href="<?php echo e(asset('/assets/plugins/DataTables/datatables.min.css')); ?>" rel="stylesheet">

    <!-- trix editor -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('/assets/css/trix.css')); ?>">
    <script type="text/javascript" src="<?php echo e(asset('/assets/js/trix.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('css-plugins'); ?>

</head>
<body>

    <div class='loader'>
        <div class='spinner-grow text-primary' role='status'>
          <span class='sr-only'>Loading...</span>
        </div>
    </div>

    <div class="page-container">

    <?php echo $__env->make('components.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <div class="page-content">
            <div class="main-wrapper">
                
                <?php echo $__env->yieldContent('content'); ?>
                
            </div>
        </div>
    </div>

    

    <!-- Javascripts -->
    <script src="<?php echo e(asset('/assets/plugins/jquery/jquery-3.4.1.min.js')); ?>"></script>
    <script src="https://unpkg.com/@popperjs/core@2"></script>
    <script src="<?php echo e(asset('/assets/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
    <script src="https://unpkg.com/feather-icons"></script>
    <script src="<?php echo e(asset('/assets/plugins/perfectscroll/perfect-scrollbar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/plugins/apexcharts/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/main.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/pages/dashboard.js')); ?>"></script>

    <script src="<?php echo e(asset('/assets/plugins/DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/assets/js/pages/datatables.js')); ?>"></script>

    <?php echo $__env->yieldPushContent('javascript-plugins'); ?>
    
</body>
</html><?php /**PATH C:\Users\Ihsan\Desktop\toko-laptop-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>