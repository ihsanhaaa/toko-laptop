<div class="page-header">
    <nav class="navbar navbar-expand-lg d-flex justify-content-between">
        <div class="" id="navbarNav">
            <ul class="navbar-nav" id="leftNav">
                <li class="nav-item">
                    <a class="nav-link" id="sidebar-toggle" href="#"><i data-feather="arrow-left"></i></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Settings</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Help</a>
                </li>
            </ul>
        </div>
        <div class="logo">
            <a class="navbar-brand" href="<?php echo e(url('/')); ?>"></a>
        </div>
        <div class="" id="headerNav">
            <ul class="navbar-nav">
                <li class="nav-item dropdown">
                    <a class="nav-link search-dropdown" href="#" id="searchDropDown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false"><i data-feather="search"></i></a>
                    <div class="dropdown-menu dropdown-menu-end dropdown-lg search-drop-menu"
                        aria-labelledby="searchDropDown">
                        <form>
                            <input class="form-control" type="text" placeholder="Type something.."
                                aria-label="Search">
                        </form>
                    </div>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link profile-dropdown" href="#" id="profileDropDown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false"><img
                            src="../../assets/images/avatars/profile-image.png" alt=""></a>
                    <div class="dropdown-menu dropdown-menu-end profile-drop-menu" aria-labelledby="profileDropDown">
                        <?php if(auth()->guard()->guest()): ?>
                            <a class="dropdown-item" href="<?php echo e(route('login')); ?>"><i
                                    data-feather="inbox"></i><?php echo e(__('Masuk')); ?></a>
                        <?php else: ?>
                            <a class="dropdown-item" href="<?php echo e(route('home')); ?>"><i data-feather="user"></i>Profile</a>
                            <a class="dropdown-item" href="#"><i data-feather="inbox"></i>Product</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#"><i data-feather="settings"></i>Settings</a>
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i
                                    data-feather="log-out"></i><?php echo e(__('Keluar')); ?></a>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        <?php endif; ?>
                    </div>
                </li>
            </ul>
        </div>
    </nav>
</div>
<div class="page-sidebar">
    <ul class="list-unstyled accordion-menu">

        <?php if(auth()->guard()->guest()): ?>
            <li class="sidebar-title">
                Main
            </li>
            <li class="active-page">
                <a href="<?php echo e(route('login')); ?>"><i data-feather="home"></i><?php echo e(__('Masuk')); ?></a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>"><i data-feather="calendar"></i>Produk</a>
            </li>
        <?php else: ?>
            <li class="sidebar-title">
                Main
            </li>
            <li class="active-page">
                <a href="index.html"><i data-feather="home"></i>Dashboard</a>
            </li>
            <li class="sidebar-title">
                Apps
            </li>
            <li>
                <a href="email.html"><i data-feather="inbox"></i>Beranda</a>
            </li>
            <li>
                <a href="<?php echo e(route('product.index')); ?>"><i data-feather="calendar"></i>Manajemen Produk</a>
            </li>
            <li>
                <a href="<?php echo e(url('/')); ?>"><i data-feather="calendar"></i>Produk</a>
            </li>
            <li>
                <a href="<?php echo e(route('logout')); ?>"><i data-feather="calendar" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"></i><?php echo e(__('Keluar')); ?></a>
                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                    <?php echo csrf_field(); ?>
                </form>
            </li>
        <?php endif; ?>
    </ul>
</div>
<?php /**PATH C:\Users\Ihsan\Desktop\toko-laptop-app\resources\views/components/navbar.blade.php ENDPATH**/ ?>