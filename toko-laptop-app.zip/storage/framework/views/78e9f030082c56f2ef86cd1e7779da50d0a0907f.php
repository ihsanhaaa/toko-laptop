

<?php $__env->startSection('content'); ?>

    <?php $__env->startPush('css-plugins'); ?>
        <!-- Bootstrap Css -->
        <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css">
        <!-- Icons Css -->
        <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
        <!-- App Css-->
        <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css">
    <?php $__env->stopPush(); ?>

    <!-- Begin page -->
    <div id="layout-wrapper">

        <?php echo $__env->make('components.navbar_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="main-content">

            <div class="page-content">
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="page-title-box">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h6 class="page-title">Buat User Baru</h6>
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="<?php echo e(url('/home')); ?>">Dashboard</a></li>
                                    <li class="breadcrumb-item"><a href="<?php echo e(route('users.index')); ?>">Manajemen User</a></li>
                                    <li class="breadcrumb-item active" aria-current="page">Buat User</li>
                                </ol>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <strong><?php echo e($error); ?></strong><br>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>

                    <div class="row">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <?php echo Form::open(['route' => 'users.store', 'method' => 'POST']); ?>


                                    <div class="mb-3">
                                        <label class="form-label" for="name">Nama Lembaga :</label>
                                        <?php echo Form::text('name', null, ['placeholder' => 'Nama Lembaga', 'class' => 'form-control']); ?>

                                    </div>

                                    <div style="margin-bottom: 70px;">
                                        <label class="form-label" for="role">Role :</label><br>
                                        <?php echo Form::select('roles[]', $roles, [], ['class' => 'form-control', 'multiple']); ?>

                                    </div>

                                    <div class="my-3">
                                        <label class="form-label" for="email">Email :</label><br>
                                        <?php echo Form::text('email', null, ['placeholder' => 'Email', 'class' => 'form-control']); ?>

                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label" for="password">Password :</label>
                                        <?php echo Form::password('password', ['placeholder' => 'Password', 'class' => 'form-control']); ?>

                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label" for="confirm-password">Konfirmasi Password :</label><br>
                                        <?php echo Form::password('confirm-password', ['placeholder' => 'Konfirmasi Password', 'class' => 'form-control']); ?>

                                    </div>

                                    

                                    <button type="submit" class="btn btn-primary">
                                        Simpan
                                    </button>
                                    <?php echo Form::close(); ?>

                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                <!-- end row -->

            </div> <!-- container-fluid -->
        </div>
        <!-- End Page-content -->

        <?php echo $__env->make('components.footer_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </div>
    <!-- END layout-wrapper -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <?php $__env->startPush('javascript-plugins'); ?>
        <!-- JAVASCRIPT -->
        <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>

        <!-- form repeater js -->
        <script src="<?php echo e(asset('assets/libs/jquery.repeater/jquery.repeater.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/pages/form-repeater.int.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    <?php $__env->stopPush(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ihsan\Desktop\toko-laptop-app\resources\views/users/create.blade.php ENDPATH**/ ?>