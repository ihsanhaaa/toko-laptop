@extends('layouts.app')

@section('content')
    @include('components.navbar_admin')


@endsection
